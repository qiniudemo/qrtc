# QRTC
Qrtc 是连麦服务端工具，可以更方便地创建，查看，删除连麦房间以及生成RoomToken
文档详情： [Server 连麦](http://developer.qiniu.com/article/pili/sdk/server-rtc-sdk.html)

## Usage
### 配置
使用本工具首先需要配置`conf.json`文件，填写相应的七牛ak/sk
当然你也可以不设置，进入工具的页面后，如果检查到没有设置ak／sk，会进入一个登录页面来设置ak／sk。
> 工具不会对ak/sk正确性进行校验

### 使用
首先给`qrtc`可执行权限：`chmod +x qrtc`，然后通过命令行运行本工具。
然后访问 localhost:8080 即可进入本工具


## API
获取连麦token：
>POST /room/\<room_name\>/user/\<user_id\>/token
 Host: \<localhost\>
 
 RoomName: 房间名称。
UserID: 请求加入房间的用户ID。
该API生成权限(perm)为`user`,有效时间为永久的RoomToken
相关文档：[RoomToken计算](http://developer.qiniu.com/article/pili/sdk/server-rtc-sdk.html#6)

获取推流地址：
>POST /stream/<room_name>
>Host: \<localhost\>
>RoomName: 房间名称。

获取播放地址：
> GET /stream/<room_name>/play
> Host: \<localhost\>
> RoomName: 房间名称。


